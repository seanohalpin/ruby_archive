# Test case for the extremely lazy
def did_it_work?
  "yes"
end
